"""
This module aims at providing function to clean and archive unused dashboard and cards
"""
