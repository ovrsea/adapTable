"""
This module aims at fixing graphs once refactoring has been done in your database.
While not being perfect, it provides for some specific use case a nice 80/20 that avoid lot's of manual and
automatic work
"""
