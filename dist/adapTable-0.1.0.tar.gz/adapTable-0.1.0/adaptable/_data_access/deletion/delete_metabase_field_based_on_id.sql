DELETE FROM public.metabase_field
WHERE id = %(metabase_field_id)s;