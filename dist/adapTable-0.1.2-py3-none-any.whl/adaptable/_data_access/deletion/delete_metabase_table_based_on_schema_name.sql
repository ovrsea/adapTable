DELETE FROM public.metabase_table
WHERE schema = %(schema_name)s;