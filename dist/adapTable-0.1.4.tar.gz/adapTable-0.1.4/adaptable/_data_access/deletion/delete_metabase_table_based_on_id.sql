DELETE FROM public.metabase_table
WHERE id = %(metabase_table_id)s;